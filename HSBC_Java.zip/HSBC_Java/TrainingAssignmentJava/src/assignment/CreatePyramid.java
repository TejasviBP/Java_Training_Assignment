package assignment;

public class CreatePyramid {
	public static void main(String[] args) {
      char x='*';
      for(int i=0;i<6;i++) {
    	  System.out.println("   "+x+" ");
    	  for(int j=0;j<=i;j++) {
        	  System.out.print("   "+x+" ");
      }
    	  
      }
      
	}
}
