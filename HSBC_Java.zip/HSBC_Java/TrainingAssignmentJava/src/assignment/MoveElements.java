package assignment;
//Move all 0 to end or start of array (int a[] = {1,0,7,8,6,4,0,0})

import java.util.Arrays;

public class MoveElements {

public static void main(String[] args) {
	int a[] = {1,0,7,8,6,4,0,0};
	Arrays.sort(a);
	System.out.println(Arrays.toString(a));
	
}

}
;