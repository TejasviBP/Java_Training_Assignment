package assignment;

public class DisplayCharacters {
public static void main(String[] args) {
	char ch='a';
	while(ch<='z') {
		System.out.print(" "+ch);
		ch++;
	}
	System.out.println();
	System.out.println();
	char ch1='A';
	while(ch1<='Z') {
		System.out.print(" "+ch1);
		ch1++;
	}
}
}
