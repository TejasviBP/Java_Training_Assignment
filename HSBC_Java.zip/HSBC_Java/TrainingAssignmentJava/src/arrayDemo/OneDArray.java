package arrayDemo;

import java.util.Arrays;

public class OneDArray {

	
	public static void main(String[] args) {
	//initialization and declaration
		int [] array= new int [5]; 
	array[0]=1;
	array[1]=2;
	array[2]=5;
	array[3]=7;
	array[4]=4;
	for(int i=0; i<array.length;i++) {
	
		
		System.out.println(array[i]);
	
	
	}
	
	}

}
